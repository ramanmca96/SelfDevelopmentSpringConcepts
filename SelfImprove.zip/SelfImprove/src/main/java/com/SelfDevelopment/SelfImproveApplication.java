package com.SelfDevelopment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SelfImproveApplication {

	public static void main(String[] args) {
		SpringApplication.run(SelfImproveApplication.class, args);
	}

}
